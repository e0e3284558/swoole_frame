<?php

namespace SwooleTest\Redis;


class DBConnectException extends \Exception
{

}