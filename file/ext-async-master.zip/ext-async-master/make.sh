phpize --clean
phpize
./configure 
make clean
make -j
make install
